import { Component, OnInit } from '@angular/core';
import { User } from "./../../models/app.user.model";
import { Role } from "./../../models/app.role.model";
import { FormGroup, FormControl, Validator, Validators } from '@angular/forms';
import { Response } from "@angular/http";
import { UserService } from 'src/services/UserService';
import { RoleService } from "./../../services/RoleService"
import { Router } from '@angular/router';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  user: User;
  token: string;
  roles: Array<Role>;
  message: string;
  frmUser: FormGroup;

  constructor(private roleserv: RoleService , private userServ: UserService, private route: Router) {
      this.user = new User("","","",0);
      this.roles = new Array<Role>();
      this.token = sessionStorage.getItem("token");
      this.message = "";

      this.frmUser = new FormGroup({
        userName: new FormControl(this.user.userName,
                                          Validators.compose([
                                            Validators.nullValidator,
                                            Validators.required,
                                            Validators.pattern("[a-zA-Z]*")
                                          ])
        ),
        emailAddress: new FormControl(this.user.emailAddress,
                                            Validators.compose([
                                              Validators.required,
                                              Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")
                                            ])
        ),
        password: new FormControl(this.user.password,
                                              Validators.compose([
                                                Validators.required
                                              ])
        ),
        roleId: new FormControl(this.user.roleId,
                                    Validators.compose([
                                      Validators.required
                                    ])
        ),
      })
  }

  ngOnInit() {
    this.roleserv.getRolesData(this.token).subscribe(
        (resp: Response) => {
          this.roles = resp.json().data;
        },
        error => {
          console.log(`Error Occured ${error}`);
        }
    )
  }

  save(){
      this.user = this.frmUser.value;

      this.userServ.postUserData(this.user, this.token).subscribe(
          (resp: Response) => {
           this.message = resp.json().message;
          },
          error => {
            console.log(`Error Occured ${error}`);
          }
        );
  }

  clear(){
    this.user = new User("","","",0);
    this.message = "";
  }

}
