export class User {
  constructor(
    public userName: string,
    public emailAddress: string,
    public password: string,
    public roleId: number
  ){}
}

export const Users =[{}];
