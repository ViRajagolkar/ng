import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from "rxjs";
import { User } from "./../models/app.user.model";

@Injectable()
export class UserService {
    url: string;
    constructor(private http : Http){
        this.url = "http://localhost:4040";
    }

    getLoginInfo(usr: User ): Observable<Response> {
        let resp: Observable<Response>;

        let header : Headers = new Headers({
          'Content-Type': 'application/json'
        });

        let options : RequestOptions = new RequestOptions();
        options.headers = header;

        resp = this.http.post(`${this.url}/api/users/auth`, JSON.stringify(usr), options);
        return resp;
    }

    getUserData(token : string): Observable<Response>{
        let resp: Observable<Response>;

        let header : Headers = new Headers({
            'Content-Type':'application/json',
            'authorization':'bearer ' + token
        });
        let options : RequestOptions = new RequestOptions();
        options.headers = header;

        resp = this.http.get(`${this.url}/api/users`,options);
        return resp;
    }

    postUserData(usr: User, token: string): Observable<Response>{
      let resp: Observable<Response>;

      let header : Headers = new Headers({
        'Content-Type': 'application/json',
        'authorization': 'bearer ' + token
      });

      let options : RequestOptions = new RequestOptions();
      options.headers = header;

      resp = this.http.post(`${this.url}/api/users`, JSON.stringify(usr), options);
      return resp;
    }
}
